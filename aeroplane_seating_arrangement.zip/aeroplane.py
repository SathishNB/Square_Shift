class Aeroplane:
    # Constructor with Processed inputs - Input1 & Input2 as Parameters
    def __init__(self, seating_grid_dimension, passengers):
        self.seats = []
        self.seating_grid_dimension = seating_grid_dimension
        self.passengers = passengers
        self.rows = []
        self.filled = 0
    
    # Constructing a 3D List to allot seats for given PassengerIDS
    def construct(self):
        for block in self.seating_grid_dimension:
            rows = block[1]
            cols = block[0]
            self.rows.append(rows)
            self.seats.append([["xx"] * cols for i in range(rows)])

    # Filling Aisle seats
    def aisle_seats(self):
        block = len(self.seating_grid_dimension)
        # Iterating through rows....upto maximum row number on considering whole block
        for row in range(max(self.rows)):
            # Iterating through each blocks
            for i in range(block):
                # Checking if the row is available in the current block
                if self.seating_grid_dimension[i][1] > row:
                    # Checking for aisle column in first and last block
                    if (i == 0 or i == block - 1) and self.seating_grid_dimension[i][0] > 1:
                        aisleCol = self.seating_grid_dimension[i][0] - 1
                        self.seats[i][row][aisleCol] = self.passengers[self.filled]
                        self.filled += 1

                    # Filling aisle seats in both corners of the block
                    else:
                        aisleCol = 0
                        self.seats[i][row][aisleCol] = self.passengers[self.filled]
                        self.filled += 1
                        # Checking if all passengers are seated
                        if self.filled >= len(self.passengers):
                            break
                        
                        # Checking if the block is having more than 1 column
                        if self.seating_grid_dimension[i][0] > 1:
                            aisleCol = self.seating_grid_dimension[i][0] - 1
                            self.seats[i][row][aisleCol] = self.passengers[self.filled]
                            self.filled += 1
                            
                    # Checking if all passengers are seated
                    if self.filled >= len(self.passengers):
                        break

    # Window seats
    def window_seats(self):
        block = len(self.seating_grid_dimension)
        # Iterating through rows....upto maximum row number on considering whole block and filling both window seats in a row each time
        for row in range(max(self.rows)):
            # Checking if the row is available in the current block
            if self.seating_grid_dimension[0][1] > row:
                self.seats[0][row][0] = self.passengers[self.filled]
                self.filled += 1
                if self.filled >= len(self.passengers):
                    break
            # Checking if the row is available in the current block
            if self.seating_grid_dimension[block - 1][1] > row:
                window = self.seating_grid_dimension[block - 1][0] - 1
                self.seats[block - 1][row][window] = self.passengers[self.filled]
                self.filled += 1
                if self.filled >= len(self.passengers):
                    break

    # Middle seats
    def middle_seats(self):
        block = len(self.seating_grid_dimension)
        # Iterating through rows....upto maximum row number on considering whole block and filling all middle seats in a row each time
        for row in range(max(self.rows)):
            # Iterating through each blocks
            for i in range(block):
                # Checking if the current row of the block is having more than 2 seats (i.e.,)Checking for middle seats  
                if self.seating_grid_dimension[i][1] > row and self.seating_grid_dimension[i][0] > 2:
                    for col in range(1, self.seating_grid_dimension[i][0] - 1):
                        self.seats[i][row][col] = self.passengers[self.filled]
                        self.filled += 1
                        # Checking if all passengers are seated
                        if self.filled >= len(self.passengers):
                            break
                # Checking if all passengers are seated
                if self.filled >= len(self.passengers):
                    break
            # Checking if all passengers are seated
            if self.filled >= len(self.passengers):
                break

    # Printing the output Seating blocks
    def print_seats(self):
        for block in self.seats:
            for row in block:
                print(row)
            print()
        print()
