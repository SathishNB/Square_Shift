import re
from aeroplane import Aeroplane


# Checking whether a number is prime or not
def isPrime(n):
    if n == 1:
        return 0
    k = round(n**0.5)
    for i in range(2, k+2):
        if n % i == 0:
            return 0
    return 1

# ordering the seats
def orderSeating(seating):
    prime = []
    power_of_2 = []
    other_ids = []
    ordered_seating = []
    for id in seating:
        if isPrime(id) == 1:
            prime.append(id)
        elif (id & (id - 1)) == 0 and id != 2:
            power_of_2.append(id)
        else:
            other_ids.append(id)
    ordered_seating = prime + power_of_2 + other_ids
    return ordered_seating

# Inputs
seating_grid = input()
passengers = input()

# converting inputs in string format to list of integers
seating_grid = re.split('[,\[\]]', seating_grid)

# Converting List of strings to List of integers
seating_grid_dimension = []
for x in seating_grid:
    try:
        seating_grid_dimension.append(int(x))
    except:
        continue
    
# Converting 2nd input(string) into a List of integers
passengers = re.split(",", passengers[1:-1])
passengers = [int(x) for x in passengers]

seating_grid = seating_grid_dimension

# Converting list of Input-1 into 2D array
seating_grid_dimension = []
grid = []
# [2,3,4,5]
# [[2,3],[4,5]]
for i in range(len(seating_grid)):
    grid.append(seating_grid[i])
    if len(grid) == 2:
        seating_grid_dimension.append(grid)
        grid = []


# Arranging the passenger IDs according to the priority
passengers = orderSeating(passengers)

# Creating an instance of an object
aeroplane_obj = Aeroplane(seating_grid_dimension, passengers)
aeroplane_obj.construct()
aeroplane_obj.aisle_seats()
aeroplane_obj.window_seats()
aeroplane_obj.middle_seats()
print()
aeroplane_obj.print_seats()
